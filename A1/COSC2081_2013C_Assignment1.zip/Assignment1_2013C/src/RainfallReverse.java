/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author v90207
 */
class RainFallReverse {
    public static void main(String[] args){
        // type your code here
    }
    
    public static void printReverse (int number) { // return type can be changed if necessary
        // type your code here
    }
	
	public static void listRainFallStatistics() {
	// type your code here
}

 public static void MainMenu () {
 // type your code here
 }
}