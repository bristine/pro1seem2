package vn.edu.rmit.prog1.labs;

public class Lab1 {

    public static void main(String[] args) {
        /**
         * TODO
         * Make a class Animal
         * Make a subclass of Animal called Fish
         * Make a subclass of Animal called Bird
         *
         * Put common properties and methods in the Animal class
         *
         * In Fish class, add a method:
         * public boolean canSwim()
         *
         * In Bird class, add a method:
         * public boolean canFly()
         *
         * Ensure that all classes have an appropriate constructor
         * Ensure that you are calling the superclass constructors
         */
    }
}