
package vn.edu.rmit.prog1.demos2;

public class Demo {

    public static void main(String[] args) {

        Demo d = new Demo();
    }
}