package vn.edu.rmit.prog1.demos2;

public class Kiwi extends Bird {

    public Kiwi(String n) {
        super(n);
    }
}