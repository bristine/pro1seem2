package vn.edu.rmit.prog1.demos2;

public class Robin extends Bird {

    public Robin(String n) {
        super(n);
    }
}