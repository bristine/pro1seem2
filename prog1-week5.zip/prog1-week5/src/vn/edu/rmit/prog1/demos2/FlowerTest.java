package vn.edu.rmit.prog1.demos2;

public class FlowerTest {

    public static void main(String[] args) {
        Rose r1 = new Rose(10.0d, "smelly", "fred", "jungle", "red");
        System.out.println(r1);
    }

}