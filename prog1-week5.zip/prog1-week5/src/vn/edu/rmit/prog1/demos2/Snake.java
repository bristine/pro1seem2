package vn.edu.rmit.prog1.demos2;

public class Snake extends Animal {

    public Snake(String s) {
        super(s);
    }

    public String eat() {
        return "I'm eating rats";
    }

}