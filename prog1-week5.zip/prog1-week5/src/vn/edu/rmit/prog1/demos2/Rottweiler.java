package vn.edu.rmit.prog1.demos2;

public class Rottweiler extends Dog {

    public Rottweiler(String n) {
        super(n);
    }

}