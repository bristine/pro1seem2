package vn.edu.rmit.prog1.demos2;

public class Rose extends Flower {

    protected double price;

    public Rose(double price, String fragrance, String name, String habitat, String colour) {
        super(fragrance, name, habitat, colour);
        this.price = price;
    }

    @Override
    public String toString() {
        return this.name + " " + this.fragrance + " " + this.price;
    }

}