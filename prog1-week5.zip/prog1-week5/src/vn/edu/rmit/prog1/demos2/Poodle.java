package vn.edu.rmit.prog1.demos2;

public class Poodle extends Dog {

    public Poodle(String n) {
        super(n);
    }
}