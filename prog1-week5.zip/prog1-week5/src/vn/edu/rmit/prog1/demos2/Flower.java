package vn.edu.rmit.prog1.demos2;

public class Flower extends Plant {

    protected String fragrance;

    public Flower(String fragrence, String name, String habitat, String colour) {
        super(name, habitat, colour);
        this.fragrance = fragrence;
    }
}