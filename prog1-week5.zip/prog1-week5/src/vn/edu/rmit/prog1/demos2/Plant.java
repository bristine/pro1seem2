package vn.edu.rmit.prog1.demos2;

public class Plant {

    protected String name;
    protected String colour;
    protected String habitat;

    public Plant(String name, String habitat, String colour) {
        this.name = name;
        this.habitat = habitat;
        this.colour = colour;
    }

}