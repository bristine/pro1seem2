package vn.edu.rmit.prog1.demos2;

public class Dog extends Animal {

    public Dog(String name) {
        super(name);
    }
}