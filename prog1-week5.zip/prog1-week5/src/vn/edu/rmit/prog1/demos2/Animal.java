package vn.edu.rmit.prog1.demos2;

public class Animal {

    protected String name;
  
    public Animal(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String eat() {
        return "I'm eating food.";
    }

}