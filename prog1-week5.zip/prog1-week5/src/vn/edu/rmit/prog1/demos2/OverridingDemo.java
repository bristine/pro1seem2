package vn.edu.rmit.prog1.demos2;

public class OverridingDemo {

    public static void main(String[] args) {
        Monkey m = new Monkey("Bob");
        Snake s = new Snake("Cyril");
        Fish f = new Fish("Fred");

        System.out.println(m.getName() + ": " + m.eat());
        System.out.println(s.getName() + ": " + s.eat());
        System.out.println(f.getName() + ": " + f.eat());
    }

}