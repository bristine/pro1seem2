package vn.edu.rmit.prog1.demos2;

public class Fish extends Animal {

    public Fish(String n) {
        super(n);
    }
}