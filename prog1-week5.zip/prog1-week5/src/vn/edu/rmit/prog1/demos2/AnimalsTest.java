package vn.edu.rmit.prog1.demos2;

public class AnimalsTest {

    public static void main(String[] args) {
        Poodle p = new Poodle("Linh");
        Rottweiler r = new Rottweiler("Minh");

        System.out.println(p.getName());
        System.out.println(r.getName());
    }

}