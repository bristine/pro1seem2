package vn.edu.rmit.prog1.demos2;

public class Bird extends Animal {

    public Bird(String name) {
        super(name);
    }

}