package vn.edu.rmit.prog1.demos2;

public class Monkey extends Animal {

    public Monkey(String name) {
        super(name);
    }

    @Override
    public final String eat() {
        return "I'm eating banananananannans";
    }

}