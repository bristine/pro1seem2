package vn.edu.rmit.prog1.demos;


public class Room {

    private int numberOfPeople;
    protected String roomNumber = "";

    public Room(int numberOfPeople) {
        this.numberOfPeople = numberOfPeople;
    }

    public double roomCharge() {
        return numberOfPeople * 19.5d;
    }

    public int getNumberOfPeople() {
        return numberOfPeople;
    }

    public void setNumberOfPeople(int numberOfPeople) {
        this.numberOfPeople = numberOfPeople;
    }

    
}