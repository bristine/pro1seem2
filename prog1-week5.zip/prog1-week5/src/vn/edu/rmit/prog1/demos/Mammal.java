package vn.edu.rmit.prog1.demos;

public class Mammal {

    private int legs = 4;
    private int eyes = 2;

    public int getEyes() {
        return eyes;
    }

    public void setEyes(int eyes) {
        this.eyes = eyes;
    }

    public int getLegs() {
        return legs;
    }

    public void setLegs(int legs) {
        this.legs = legs;
    }

}