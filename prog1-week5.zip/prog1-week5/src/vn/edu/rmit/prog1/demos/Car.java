package vn.edu.rmit.prog1.demos;

public class Car extends Vehicle {

    public Car(int w) {
        this.wheels = w;
    }

    public String washRoof() {
        return "roof is now clean";
    }

}