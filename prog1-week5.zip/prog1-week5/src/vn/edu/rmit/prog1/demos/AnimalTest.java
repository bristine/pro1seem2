package vn.edu.rmit.prog1.demos;

public class AnimalTest {

    public static void main(String[] args) {
        Elephant jumbo = new Elephant();
        jumbo.setEyes(1);
        System.out.println("Elephant jumbo has: " + jumbo.getEyes()+" eyes");
        System.out.println("Elephant jumbo has: " + jumbo.getLegs()+" legs");
        Dog scoobyDoo = new Dog();
        System.out.println("Dog scoobyDoo has: " + scoobyDoo.getEyes()+" eyes");
        System.out.println("Dog scoobyDoo has: " + scoobyDoo.getLegs()+" legs");

        //type(class) variableName = new Constructor();
        Mammal thing = new Elephant();
        System.out.println("Thing has: "+ thing.getEyes());
        jumbo.getName();

        Mammal thing2 = new Mammal();
        Cat c = new Cat();
        System.out.println("C has: "+ c.getEyes());
    }

}