package vn.edu.rmit.prog1.demos;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;

public class Circle extends GeoShape {

    private double radius;
    
    public Circle(double r, Color color, boolean fill, double x, double y) {
        this.radius = r;
        this.color = color;
        this.filled = fill;
        this.x = x;
        this.y = y;
    }
    
    public void draw(Graphics2D g) {
        Shape c = new Ellipse2D.Double(x, y, radius*2, radius*2);
        g.setPaint(color);
        g.draw(c);
        if(filled) {
            g.fill(c);
        }
    }
}