package vn.edu.rmit.prog1.demos;

import java.awt.Color;

public class Dog extends Mammal {

    private Color color = Color.BLACK;
    private String name;

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}