package vn.edu.rmit.prog1.demos;

public class Cat extends Mammal {

}