package vn.edu.rmit.prog1.demos;

public class Bike extends Vehicle {

    public Bike(int w) {
        this.wheels = w;
    }

}