package vn.edu.rmit.prog1.demos;

import java.awt.Color;

public class Elephant extends Mammal {

    private Color colour = Color.GRAY;
    private String name = "";

    public Color getColour() {
        return colour;
    }

    public void setColour(Color colour) {
        this.colour = colour;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}