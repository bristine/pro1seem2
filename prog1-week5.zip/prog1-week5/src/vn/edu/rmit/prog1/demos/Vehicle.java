package vn.edu.rmit.prog1.demos;

public class Vehicle {

    protected int wheels;

    public void setWheels(int w) {
        this.wheels = w;
    }

    public int getWheels() {
        return this.wheels;
    }

}