package vn.edu.rmit.prog1.demos;

import java.util.Date;
import java.util.TimeZone;

public class DateDemo {

    public static void main(String[] args) {
        Date today = new Date();
        TimeZone tz = TimeZone.getDefault();

        System.out.println("Today: "+today);
        System.out.println("Current timezone: "+tz.getDisplayName());

        Date start = new Date();
        xMethod();
        Date stop = new Date();

        System.out.println("Time elapsed: "+(stop.getTime()-start.getTime()));
    }

    public static void xMethod() {
        try {
            Thread.sleep(5000);
        } catch(Exception e) {}
    }

}