package vn.edu.rmit.prog1.demos;

import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Color;

public class Main extends Frame {

    public static void main(String[] args) {
        Main m = new Main();
        m.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        m.setSize(640,480);
        m.setVisible(true);
    }

    public void paint(Graphics g) {
        Graphics2D ga = (Graphics2D)g;
        
        Square s = new Square(200, Color.RED, true, 400, 100);
        s.draw(ga);
        Circle c = new Circle(50, Color.GREEN, true, 100, 100);
        c.draw(ga);

        GeoShape gs = new GeoShape();
        gs.draw(ga);
        
    }

}