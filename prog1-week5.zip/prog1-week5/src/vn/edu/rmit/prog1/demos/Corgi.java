package vn.edu.rmit.prog1.demos;

public class Corgi extends Dog {

    public Corgi() {
        // does nothing
    }

    public Corgi(String name) {
        this.setName(name);
    }

}