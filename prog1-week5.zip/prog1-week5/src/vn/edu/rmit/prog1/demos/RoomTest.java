package vn.edu.rmit.prog1.demos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class RoomTest {

    public static void main(String[] args) {
        DoubleRoom dr = new DoubleRoom(2,"101");
        SingleRoom sr = new SingleRoom("102");
        System.out.println("single: " + sr.roomCharge());
        System.out.println("double: " +dr.roomCharge());

        List al = new ArrayList();

        al.add(1);
        al.add(11);
        al.add(111);
        al.add(1111);
        al.add(11111);
        al.add("Hello");


        for(int i=0; i<al.size(); i++) {
            System.out.println(al.get(i));
        }

        // enhanced for-loop
//        for(Integer i : al) {
//            System.out.println(i);
//        }

        // iterator
        for(Iterator it = al.iterator(); it.hasNext();) {
            System.out.println(it.next());
        }
    }

}