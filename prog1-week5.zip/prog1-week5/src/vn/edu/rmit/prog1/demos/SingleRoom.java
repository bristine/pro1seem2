package vn.edu.rmit.prog1.demos;

public class SingleRoom extends Room {

    public SingleRoom(String roomNumber) {
        super(1);
        this.roomNumber = roomNumber;
    }
}