package vn.edu.rmit.prog1.demos;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;

public class Square extends GeoShape {

    private double sideLength;
    
    
    public Square(double sideLength, Color color, boolean fill, double x, double y) {
        this.sideLength = sideLength;
        this.color = color;
        this.filled = fill;
        this.x = x;
        this.y = y;
    }
    
    public void draw(Graphics2D g) {
        Shape s = new Rectangle2D.Double(x, y, sideLength, sideLength);
        g.setPaint(color);
        g.draw(s);
        if(filled) {
            g.fill(s);
        }
    }
    
}