package vn.edu.rmit.prog1.demos;

import java.awt.Color;
import java.awt.Graphics2D;

public class GeoShape {

    protected Color color;
    protected boolean filled;
    protected double x;
    protected double y;

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }

    public void draw(Graphics2D g) {
        System.out.println("Cannot draw a 'shape'");
    }

}