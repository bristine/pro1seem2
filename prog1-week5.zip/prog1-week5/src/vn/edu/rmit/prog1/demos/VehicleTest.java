package vn.edu.rmit.prog1.demos;

public class VehicleTest {

    public static void main(String[] args) {
        Car c = new Car(4);
        Bike b = new Bike(2);

        System.out.println("Bike has: "+b.getWheels());
        System.out.println("Car has: "+c.getWheels());
        System.out.println(c.washRoof());
    }

}