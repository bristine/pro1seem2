package vn.edu.rmit.prog1.demos;

public class DoubleRoom extends Room {

    private float price;

    public DoubleRoom(int guests, String roomNumber) {
        super(guests);
        this.price = 100.0f;
        this.roomNumber = roomNumber;
    }

    @Override
    public double roomCharge() {
        return getNumberOfPeople() * 25.5f;
    }
}