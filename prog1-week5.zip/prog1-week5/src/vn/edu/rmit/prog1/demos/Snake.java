package vn.edu.rmit.prog1.demos;

import java.awt.Color;

public class Snake {

    private int legs = 0;
    private int eyes = 2;
    private Color colour = Color.GREEN;
    private String name = "";

    public Color getColour() {
        return colour;
    }

    public void setColour(Color colour) {
        this.colour = colour;
    }

    public int getEyes() {
        return eyes;
    }

    public void setEyes(int eyes) {
        this.eyes = eyes;
    }

    public int getLegs() {
        return legs;
    }

    public void setLegs(int legs) {
        this.legs = legs;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
